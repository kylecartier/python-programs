#!/usr/bin/env python3

import os

def main():

    word = input("Enter a word: ")

    if word == "h@ck3r!":
        os.system('./Tools.py') 
    else:
        print()
        print("Have a good day!")

main()
