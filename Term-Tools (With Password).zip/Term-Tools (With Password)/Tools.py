#!/usr/bin/env python3

import os

# What do you want to do?

print() 

os.system('echo What would you like to hack on today?')

print()

# Choose command(s) to execute 

os.system('\necho Choose a command:')

print('-----------------')

# Lists options for commands or exit 

os.system('\necho uua - Maintenance; \necho tp - top; \necho ht - htop; \necho nf - neofetch; \necho ur - uname -r; \necho ifc - ifconfig; \necho ipa - ip a; \necho ping - ping; \necho ws - wireshark; \necho mn - nmap; \necho zm - zenmap; \n\echo jr - john the ripper')

print()

# Prompts user to enter a command

command = input("Enter a command: ")

# updates, upgrades, and removes packages no longer needed

if command == 'uua':
    os.system('sudo apt update && sudo apt upgrade; sudo apt autoremove')

# Run top
    
if command == 'tp':
    os.system('top')

# Run htop
    
if command == 'ht':
    os.system('htop')

# Run neofetch
    
if command == 'nf':
    os.system('neofetch')
        
# Run uname -r

if command == 'ur':
    os.system('uname -r')
    
# Run ifconfig 

if command == 'ifc':
    os.system('ifconfig')
    
# Run ip a

if command == 'ipa':
    os.system('ip a')
        
# Run ping against a machine / host
    
if command == 'ping':
    address = input("Enter ip address: ")
    os.system('ping ' + address)

# Run wirshark
    
if command == 'ws':
    os.system('wireshark &')

# Run nmap
    
if command == 'nm':
    os.system("sudo nmap -sV -O scanme.nmap.org")
      
# Run zenmap
    
if command == 'zm':
    os.system('zenmap &')
	  
# Run john the ripper
    
if command == 'jr':
    os.system('zip2john Password.zip')
    os.system('zip2john Password.zip > hash.txt')
    os.system('john --format=zip hash.txt')
    os.system('rm hash.txt')
    print()
    print("Good job hacking!")
    
else:
    print()
    print("Have a good day!")
    
# End of code
          
