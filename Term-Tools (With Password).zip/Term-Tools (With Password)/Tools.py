#!/usr/bin/env python3

import os

# What do you want to do?

print() 

os.system('echo What would you like to hack on today?')

print()

# Choose command(s) to execute 

os.system('\necho Choose a command:')

print('-----------------')

# Lists options for commands or exit 

os.system('\necho uua - maintenance; \necho i - install packages; \necho tp - top; \necho ht - htop; \necho nf - neofetch; \necho ur - uname -r; \necho ifc - ifconfig; \necho ipa - ip a; \necho ping - ping; \necho tr - traceroute; \necho ws - wireshark; \necho burp - burpsuite; \necho mn - nmap; \necho zm - zenmap; \necho jr - john the ripper')

# Prompts user to enter a command

command = input('\nEnter a command: ')

# updates, upgrades, and removes packages no longer needed

if command == 'uua':
    os.system('sudo apt update && sudo apt upgrade; sudo apt autoremove')
    
# Install a package

if command == 'i':
    package = input('Enter package to install: ')
    os.system('sudo apt install ' + package)

# Run top
    
if command == 'tp':
    os.system('top')

# Run htop
 
if command == 'ht':
    os.system('htop')
    os.system('sudo apt install htop')
    os.system('clear')
    
# Run neofetch
    
if command == 'nf':
    os.system('neofetch')
    os.system('sudo apt install neofetch')
    os.system('clear')
    os.system('neofetch')
        
# Run uname -r

if command == 'ur':
    os.system('uname -r')
    
# Run ifconfig 

if command == 'ifc':
    os.system('ifconfig')
    
# Run ip a

if command == 'ipa':
    os.system('ip a')
        
# Run ping
    
if command == 'ping':
    address = input("Enter ip address: ")
    os.system('ping ' + address)
    
# Run traceroute

if command == 'tr':
    address = input("Enter ip address: ")
    os.system('traceroute ' + address)

# Run wirshark
    
if command == 'ws':
    os.system('wireshark &')
    os.system('sudo apt install wireshark')
    os.system('clear')
    os.system('wireshark &')
     
# Run burpsuite

if command == 'burp':
    os.system('burpsuite &')
    os.system('sudo apt install burpsuite')
    os.system('clear')
    os.system('burpsuite &')

# Run nmap
    
if command == 'nm':
    os.system('nmap')
    os.system('sudo apt install nmap')
    os.system('clear')
    command = input("Enter nmap command: ")
    os.system(command)

# Example - sudo nmap -sV -O scanme.nmap.org
      
# Run zenmap
    
if command == 'zm':
    os.system('zenmap &')
    os.system('sudo apt install zenmap')
    os.system('clear')
    os.system('zenmap &')
    os.system('clear')
    	  
# Run john the ripper
    
if command == 'jr':
    os.system('zip2john Password.zip')
    os.system('zip2john Password.zip > hash.txt')
    os.system('john --format=zip hash.txt')
    os.system('rm hash.txt')
    os.system('clear')
    os.system('sudo apt install john')
    os.system('zip2john Password.zip')
    os.system('zip2john Password.zip > hash.txt')
    os.system('john --format=zip hash.txt')
    os.system('rm hash.txt')
    print('\nGood job hacking!')
    
else:
    print('\nHappy Day!')
    
# End of code

