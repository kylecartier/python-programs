#!/usr/bin/env python3

import os

# Enter the word to execute the program

word = input("Enter the word: ")

if word == "C1sc0!":
    os.system('./tools.py') 
else:
    print()
    print("Have a good day!")

# End of code
